import React, { useState } from 'react';
import Posts from './components/Posts';
import NewPost from './components/NewPost';
import Search from './components/Search';
import './App.css';

const App = () => {
  const [allPosts, setAllPosts] = useState([]);

  const addPost = text => {
    const newPost = {
      id: allPosts.length + 1,
      text: text,
    };
    setAllPosts([...allPosts, newPost]);
  };

  return (
    <>
      <div className="header">
        <h1>Twitter</h1>
      </div>
        <div className="sidebar">
          <Search posts={allPosts} />
          <NewPost onAddPost={addPost} />
        </div>
        <div className="main">
          <Posts posts={allPosts} />
        
      </div>
    </>
  );
};

export default App;
