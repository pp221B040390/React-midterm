import React from "react";

export function Navigation() {

    return (
        <nav className="h-20 flex items-center justify-between px-8 bg-gradient-to-r from-gray-600 to-gray-900 text-white shadow-lg">
          <span className="text-3xl font-extrabold tracking-wider">React-Fall-2023</span>
    
          <div className="space-x-6">

          </div>
        </nav>
      );я
}