import React, { useState } from 'react';

const NewPost = ({ onAddPost }) => {
  const [text, setText] = useState('');

  const handleSubmit = e => {
    e.preventDefault();
    if (text.trim()) {
      onAddPost(text);
      setText('');
    }
  };

  return (
    <div>
      <h2>Create a New Post</h2>
      <form onSubmit={handleSubmit}>
        <textarea
          placeholder="What's on your mind?"
          value={text}
          onChange={e => setText(e.target.value)}
        />
        <button type="submit">Post</button>
      </form>
    </div>
  );
};

export default NewPost;
