import React, { useState } from 'react';

const Search = ({ posts }) => {
  const [query, setQuery] = useState('');
  const filteredPosts = posts.filter(post => post.text.toLowerCase().includes(query.toLowerCase()));

  return (
    <div>
      <h2>Search</h2>
      <input
        type="text"
        placeholder="Search posts"
        value={query}
        onChange={e => setQuery(e.target.value)}
      />
      {query && (
        <ul>
          {filteredPosts.map(post => (
            <li key={post.id}>{post.text}</li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Search;
