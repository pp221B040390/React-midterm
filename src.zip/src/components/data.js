export const posts = [
    { id: 1, text: " " },
  ];
  